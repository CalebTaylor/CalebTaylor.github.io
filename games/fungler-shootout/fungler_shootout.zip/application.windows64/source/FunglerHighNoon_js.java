import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import ddf.minim.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class FunglerHighNoon_js extends PApplet {

int enemylow = 100, enemyhigh = 130; //difficulty of character, the range of frames the enemy can react within //<>//
int SRL = PApplet.parseInt(random(95, 100)), SRH = PApplet.parseInt(random(enemylow, enemyhigh)); // a reaction time is pulled between the enemylow values and enemyhigh values
int TimePlayer = 0; //a variable to represent the time the player presses 'space' if all conditions are ideal
boolean SlowTime = false; //boolean to handle if the first powerup is active
boolean SlowEnemy = false; //boolean to handle if the second powerup is active
int EnemyIndex = 1; // handle the enemy index for changing sprites in animation
boolean shot = false; //boolean to see if the enemy has shot the player
int cds, cd; //temporary variabes for holding the data for player's reaction time
boolean start; //boolean handeling whether it's the start of the round
boolean draw = false; //boolean handling if the game is in the draw state
int startRound = PApplet.parseInt(random(200, 250)); //value randomly chosen for a variable to countdown to to start the round
int countup; //value for counting up to start the round
boolean something = false;//values for checking if the game is counting up to the draw or counting down to the reaction time of the enemy
boolean somethingelse = false;//see above
int PowerUpSlow = 60; //value for changing the framerate when powerup1 is active
int TimeEnemy = PApplet.parseInt(random(SRL+10, SRH+20)); //modifying the reaction time of the enemy to include difficulty scaling
boolean countdownnow = true; //boolean handling if the enemy is counting down
PImage background; //next few PImages are for images throughout the game
PImage player;
PImage ui;
PImage menu;
PImage powerup1;
PImage powerup2;
boolean endall = false; // boolean for reseting all values at the start of a round
boolean playerdead = false; //bolean checking if player is dead
boolean enemydead = false; //boolean checking if enemy is dead
float a; // controlling the tint of the "get ready" ui element
int fireopacity = 255; // controlling opacity of the 'fire' ui element
int waitopacity = 0; //controlling the opacity of the 'wait' ui element
boolean presstostart = false; // boolean handling 'press e to start' ui element
boolean startofgame = true; // boolean checking if it's the start of the game
boolean makestartgo = false; // boolean for allowing the player to start the game
int startopacity = 255; //controlling tint or opacity of the 'press e to start' ui element
int sopacity = 255; //same as above for a different case
boolean endofgame = false; //handiling if it's the end of the game
boolean waiting; //waiting to fire
int startmenuopacity = 255; //handling the opacity of the start menu
boolean boolpowerup1, boolpowerup2; //seeing if the powerups are activated
int powerupopacity1 = 0, powerupopacity2 = 0; //handling opacity of powerup ui elements
int enemyindex = 0; //handling current enemy index
PImage enemy; //image for the enemy
boolean talking, idling, shooting, dying; //handling states of enemy
ArrayList<backgroundelement> element = new ArrayList<backgroundelement>(); //aray list for loading in tumbleweeds
int num = 0;//handling nunber of tumbleweeds
int numElements = 10;
boolean resetenemy = false; //handling reseting of the enemy sprite
int gameover = 0;
PImage over;
boolean talkingtome = false;
  evil_rat evilRat = new evil_rat(5,height-100,5);
  tumbleweed Weed = new tumbleweed (5,height-100,5,1);



Minim minim;

AudioPlayer song;
AudioPlayer edie;
AudioPlayer pdie;
AudioPlayer fire;
AudioPlayer powerup;

public void settings () {
  size(1280, 720); // sets screen size
  background = loadImage("background.png");
}
public void addNewelement() { //adding tumbleweeds
  int ax=width+50; 
  int ay=height-200;
  int bx = (int)random(5, 25);
  while (bx == 0) bx = (int)random(-5, 5);
  backgroundelement nextPacman = new backgroundelement(ax, ay, bx);
  element.add(nextPacman);
}
public void setup() {
  minim = new Minim (this);
  song = minim.loadFile("music.mp3");
  edie = minim.loadFile("enemydie.wav");
  pdie = minim.loadFile("playerdie.wav");
  fire = minim.loadFile("fire.wav");
  powerup = minim.loadFile("powerup.wav");
  over = loadImage("win.png");
  song.loop();

}

public void draw() {
Weed.rotateme(); //update position of rat, grass and tumbleweed
evilRat.update();
Weed.update();

  if (playerdead == true) { //if the player is dead, change sprite to dead and reset game
    enemy = loadImage(enemyindex+1+"_shot.png");
    image(enemy, 640, 80, 640, 640);
    resetenemy = true;
  }
  //addNewelement();
  println(enemyhigh);
  println(enemylow);
  if (waiting == true) { //if the player is waiting, change opacity of waiting ui element
    sinwave();
  }
  if (waiting == false) { //if not waiting, dont change the ui opacity

    a=0;
  }




  image (background, 0, 0, 1280, 720);


evilRat.drawElement();
Weed.drawElement();
  println(a);
  //if (endofgame == true) {
  //}
  //if (makestartgo == true) {
  //}



  if (playerdead == true) { //if player is dead, change sprite to dead and reseet values to start of the game
    player = loadImage("dead.png");
    image (player, 0, 80, 640, 640);
    fireopacity = 0;
    enemyhigh=145;
    enemylow=105;
    enemy = loadImage(enemyindex+1+"_shot.png");
    image(enemy, 640, 80, 640, 640);
    pdie.play();
  }
  if (playerdead == false) { //if the player isnt dead, the player is idling
    player = loadImage("idle.png");
    image (player, 0, 80, 640, 640);
  }

  if ((dying == true) && (enemyindex != 8)) { //if the enemy dies and isn't thhe last enemy, change sprite and sprite index to match

    enemy = loadImage(enemyindex+"_dead.png");
    image(enemy, 640, 80, 640, 640);
  } else if ((enemydead == false) && (enemyindex != 8)) { //if the enemy isn't dead, it just idles
    if (playerdead == false) {
      enemy = loadImage(enemyindex+1+"_idle.png");
      image(enemy, 640, 80, 640, 640);
    }
  }


  if (presstostart == true) { //when the player presses e, start the round
    tint(255, sopacity);
    ui = loadImage("s.png");
    image (ui, 500, 49, 128, 128);
    tint(255, 255);
  }
  if ((startofgame == true) || (endofgame == true)) { //if it's the starrt or end of a round, allow the player to start
    tint(255, startopacity);
    ui = loadImage("e.png");
    image (ui, 500, 49, 128, 128);
    tint(255, 255);
  }

  if (draw == true) {//when it's time to shoot, display the shoot ui element
    ui = loadImage("f.png");
    tint(255, fireopacity);
    image (ui, 500, 49, 128, 128);
    tint(255, 255);
  }
  if (draw == false) {//when it's not time to shoot, display the get ready sign

    ui = loadImage("gr.png");
    tint(255, a);
    image (ui, 500, 49, 128, 128);
    tint(255, 255);
  }

  frameRate(PowerUpSlow);
  println("Current frame rate = " + PowerUpSlow);
  println("Current enemy reaction time = " + TimeEnemy);
  println("Nummber enemy need to count down to = " + SRL);
  checkPlayer();
  if (something == true) { //start counting up until the round starts
    countup ++;
    println("When this number reaches the \"count up number\" the round will start = " + countup);
  }
  if (something == false) { //stop counting up
    countup = 0;
    println("When this number reaches the \"count up number\" the round will start = " + countup);
  }
  if (somethingelse == true) {
    println("draw!");
  }

  if (start == true) {
    startcountdown();
  }


  if (draw == true) { //if its time to draw, play the draw sound and start the enemy count down
    println("draw is true");
    fire.play();
    enemyCount();
  }



  if (boolpowerup1 == true) { //if the powerup1 is activated, make it possible to slow down time
    powerup1 = loadImage("powerup1.png");
    tint(255, powerupopacity1);
    image (powerup1, 200/2, 100, 128, 128);
    powerup.play();
    tint(255, 255);
  }
  if (boolpowerup2 == true) { //if powerup2 is activated, make it possible to slow the enemy down
    powerup2 = loadImage("powerup2.png");
    tint(255, powerupopacity2);
    image (powerup2, 240, 100, 128, 128);
    powerup.play();
    tint(255, 255);
  }
  println("Enemy Idex enemy index enemy index"+enemyindex);
  if ((enemydead == false) && (enemyindex != 8)) { //if the enemy dies, change the sprite to show the dead enemy
    if (playerdead == false) {
      enemy = loadImage(enemyindex+1+"_idle.png");
      image(enemy, 640, 80, 640, 640);
    }
  }
  if ((talkingtome == true) && (enemyindex != 8)) { //if the enemy is not dead, shooting or idling, it's talking
    enemy = loadImage(enemyindex+1+"_talk.png");
    image(enemy, 640, 80, 640, 640);
  }
  menu = loadImage("help.png");
  tint(255, startmenuopacity);
  image (menu, width/2-320, 34, 640, 640);
  tint(255, 255); 

  if (enemyindex > 7) { //if you kill all the enemies you beat the game
    enemyindex = 0;
    image(over, 0, 0);
    gameover = 255;

    frameRate(0);
  }

}

public void sinwave() { //map the opacity of the 'get ready' sign to a sin function
  a=sin(millis()*0.01f)*255;
}

public void enemyCount() {


  if (countdownnow == true) { //the enemy reaction time starts counting down
    TimeEnemy--;
  }
  if (TimeEnemy <= SRL) { //if the enemy reacts faster than the player, the player dies
    // || (TimeEnemy > TimePlayer))

    playerdead = true;
  }
  if (shot == true) { //if the player shoots before the enemy, the enemy dies
    TimePlayer = TimeEnemy;
  }
}

public void powerup1() { //roll every round to see if you get the power up

  int powerup1 = PApplet.parseInt(random(1, 7));
  if (powerup1 == 3) {
    boolpowerup1 = true;
    powerupopacity1 = 255;
    //powerup.play();
    println(powerup1);
  }
}

public void powerup2() { //roll every round to see if you get the power up

  int powerup2 = PApplet.parseInt(random(1, 7));
  if (powerup2 == 5) {
    boolpowerup2 = true;
    //powerup.play();
    println(powerup2);
    powerupopacity2 = 255;
  }
}

public void checkPlayer() { //compare reaction times to determin if the player is dead

  if (shot == true) {
    TimePlayer = cd;
  }
}

public void keyReleased() {
  if (key == ' ') {

    if ((TimeEnemy > SRL)&&(draw ==  true) && (enemydead !=true)) { //if conditions are met, the payer either shoots the enemy in time or is shot, if you press space while waiting you die
      endall = true;
      //TimeEnemy = int(random(SRL, SRH));
      //startRound = int(random(200, 400)); //new round new random values, now i need something to reset the enemy coutn down and round count down
      countdownnow = false;
      println("YOU WIN YOU WIN YOU WIN YOU WIN YOU WIN YOU WIN YOU WIN YOU WIN YOU WIN YOU WIN YOU WIN YOU WIN YOU WIN YOU WIN YOU WIN YOU WIN YOU WIN YOU WIN YOU WIN YOU WIN YOU WIN YOU WIN YOU WIN ");
      enemydead = true;
      dying=true;
      enemyindex+=1;
      //this works! now tie everything together
      fireopacity = 0;
      endofgame = true;

      waiting = false;
      edie.play();
    }
    if (waiting == true) { //handling variables while waiting, if you shoot while waiting you die
      endall = true;
      countdownnow = false;
      playerdead = true;

      fireopacity = 0;
      waiting = false;
      endofgame = true;
      resetenemy = false;
    }
  }
  if ((key == 's') && (draw != true)) {//start the countdown
    something = true;
    start = true;
    enemydead = false;
    playerdead = false;
    waitopacity = 255;
    sopacity = 0;
    waiting = true;
    talkingtome = false;
  }
  if ((key == 'r') && (boolpowerup1 == true)) { //activating the powerup

    if (PowerUpSlow == 60) {
      PowerUpSlow = 10;
    } else {
      PowerUpSlow = 60;
    }
    boolpowerup1 = false;
    powerupopacity1 = 0;
  }
  if ((key == 'n') && (boolpowerup2 == true)) {//activating the second powerup

    enemyhigh += 20;
    boolpowerup2 = false;
  }

  if (key == 'e') {
    if (enemyindex == 7) { //reseting values and starting the round
      enemyindex = 8;
    }
    //endall = true;
    TimeEnemy = PApplet.parseInt(random(enemylow, enemyhigh));
    startRound = PApplet.parseInt(random(100, 150)); //new round new random values, now i need something to reset the enemy coutn down and round count down
    countdownnow = false;
    draw = false; 
    enemydead = false;
    playerdead = false;
    waitopacity = 0;
    fireopacity = 255;
    presstostart = true;
    makestartgo = true;
    sopacity = 255;
    startofgame = false;
    endofgame=false;
    waiting = false;
    enemylow -= 0;
    enemyhigh -= 5;
    edie.rewind();
    pdie.rewind();
    fire.rewind();
    powerup.rewind();
    powerup1();
    powerup2();
    PowerUpSlow = 60;
    dying = false;
    talkingtome = true;

    if (resetenemy==true) {
      enemyindex = 0;
      resetenemy = false;
    }
  }

  if (key == 'h') { //hiding the help menu (or showing it)

    startmenuopacity = 0;
    talkingtome = true;
  }
  if (key == 'g') { //used for testing, no longer needed
    
  }
}
public void keyPressed() {

  if (key == 'h') {

    if (startmenuopacity == 0) { //showing the menu again

      startmenuopacity = 255;
    }
  }
}
public void startcountdown() {

  println("\"count up number\" = " + startRound);
  if (countup > startRound) {
    something = false;
    start = false;
    somethingelse = true;
    countup = 0;
    println("Draw!");
    draw = true;
    countdownnow = true;
  }
}




//parent class for elements in the background

class backgroundelement {

  //fields
  int x;
  int y;
  int xSpeed;


  backgroundelement(int x, int y, int xSpeed) {
    this.x=x;
    this.y=y;
    this.xSpeed=xSpeed;
  }

  public void update() {
    if (this.x <= 0) {

      //element.remove(this);
    }
  }






  //methods
  public void move() {

    //y+=ySpeed; map this shit to the sinewave function
    x+=xSpeed;
  }



  public void drawElement() {
  
    pushMatrix();
    translate(x, y);
    scale(1);
    //add image here


    popMatrix();
  }
}
//class for evil rat in the background


PImage rat;
class evil_rat extends backgroundelement {
  int x;
  int y;
  int xSpeed;

grass g1 = new grass(x,y,xSpeed);
  evil_rat(int x, int y, int xSpeed) {
    super(x, y, xSpeed);

    this.x=x;
    this.y=y;
    this.xSpeed=xSpeed;
  }
  public void update() {
    x-=xSpeed;

    if (this.x <= 0) {

      x=width;
    }
  }
  public void drawElement() {

    pushMatrix();
    translate(x, y);
    scale(1);
    //add image here
    rat = loadImage("rat.png");
    image (rat, -50, height-100, 64, 64);


    popMatrix();
  }

}
//class for grass to be aggregated in the evil rat



PImage grass1;
class grass {
  int x;
  int y;
  int xSpeed;

  grass(int x, int y, int xSpeed) {
    

    this.x=x;
    this.y=y;
    this.xSpeed=xSpeed;
  }
  public void update() {
    x-=xSpeed;

  }
  public void drawElement() {

    pushMatrix();
    translate(x, y);

    //add image here
    grass1 = loadImage("grass.png");
    image (grass1, 0, height-100, 64, 64);


    popMatrix();
  }

}
//class for making tumbleweed inherited from evil rat


PImage tumble;
class tumbleweed extends evil_rat {
  int x;
  int y;
  int xSpeed;
  int a=1;

  tumbleweed(int x, int y, int xSpeed, int a) {
    super(x, y, xSpeed);

    this.x=x;
    this.y=y;
    this.xSpeed=xSpeed;
    this.a=a;
  }
  public void update() {
    x-=xSpeed;
    a += 1;
    if (this.x <= 0) {

      x=width;
    }
    rotateme();
  }
  public void drawElement() {

    pushMatrix();
    translate(x, y);

    //add image here
    rat = loadImage("tumble1.png");
    image (rat, 0, height-100, 64, 64);


    popMatrix();
  }
  
  public void rotateme(){
  
      pushMatrix();
    rotate(radians(a+=0.1f));
popMatrix();
  
  
  }

}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "FunglerHighNoon_js" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
